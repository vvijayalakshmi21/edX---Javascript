/*
 * Implement all your JavaScript in this file!
 */
var operator = "";
var operand1 = "";
var operand2 = "";
var result = "";
var processCompleted = false;
var captureOperand2 = false;
var operatorCaptured = false;
var equalsPressed = 0;
var numPressed = "";
var displayField = $('#display');

function SetDisplayValue(numPressed){
if(operand1 != null && operand1.length > 0) {
console.log('displayfield value is ' + displayField.val());
console.log('operand1 is not null and operand2 is ' + operand2);
operand2 = operand2 + numPressed;
displayField.val(operand2);
}
else {
if(processCompleted) {
displayField.val('');
processCompleted = false;
}
var currentValue = displayField.val();
displayField.val(currentValue + numPressed);
}
console.log(displayField.val());
}


function button0clickHandler() {
SetDisplayValue('0');
}

function button1clickHandler() {
SetDisplayValue('1');
}

function button2clickHandler() {
SetDisplayValue('2');
}

function button3clickHandler() {
SetDisplayValue('3');
}

function button4clickHandler() {
SetDisplayValue('4');
}

function button5clickHandler() {
SetDisplayValue('5');
}

function button6clickHandler() {
SetDisplayValue('6');
}

function button7clickHandler() {
SetDisplayValue('7');
}

function button8clickHandler() {
SetDisplayValue('8');
}

function button9clickHandler() {
SetDisplayValue('9');
}

function clearButtonclickHandler() {
displayField.val('');
operand1 = "";
operand2 = "";
operator = "";
result = "";
processCompleted = false;
captureOperand2 = false;
operatorCaptured = false;
}

function equalsButtonclickHandler() {
if(operatorCaptured == true) {
if(captureOperand2 == false) {
operand1 = result;
}
operand2 = displayField.val();
switch(operator)
{
case '+':
result = Number(operand1) + Number(operand2);
break;

case '-':
result = Number(operand1) - Number(operand2);
break;

case '*':
result = Number(operand1) * Number(operand2);
break;

case '/':
if(operand2 == 0){
result = 'Infinity';
}
else {
result = (Number(operand1)/Number(operand2));
break;
}
default:
break;
}

displayField.val(result);
operand1 = "";
operand2 = "";
captureOperand2 = false;
operatorCaptured = false;
processCompleted = true;
}
}

function addButtonClickHandler() {
if(processCompleted == false && operatorCaptured == true) {
equalsButtonclickHandler();
}
operator = '+';
operand1 = $('#display').val(); 
captureOperand2 = true;
operatorCaptured = true;
processCompleted = false;
}

function subtractButtonClickHandler() {
if(processCompleted == false && operatorCaptured == true) {
equalsButtonclickHandler();
}
operator = '-';
operand1 = $('#display').val(); 
captureOperand2 = true;
operatorCaptured = true;
processCompleted = false;
}

function multiplyButtonClickHandler() {
if(processCompleted == false && operatorCaptured == true) {
equalsButtonclickHandler();
}
operator = '*';
operand1 = $('#display').val(); 
captureOperand2 = true;
operatorCaptured = true;
processCompleted = false;
}

function divideButtonClickHandler() {
if(processCompleted == false && operatorCaptured == true) {
equalsButtonclickHandler();
}
operator = '/';
operand1 = $('#display').val(); 
captureOperand2 = true;
operatorCaptured = true;
processCompleted = false;
}

